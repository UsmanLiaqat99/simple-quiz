<template>
  <div v-if="question">
    <div class="mainQuestion">
      <h2 class="questionTitle">
        {{ question.title }}
      </h2>
      <input class="input_label" v-if="question.type == 3" v-model="selectedAnswerShort" type="text" @change="selectAnswer" />
      <textarea class="input_label" v-if="question.type == 4" v-model="selectedAnswerLong" type="text" @change="selectAnswer" />
    </div>
  </div>
</template>

<script>
export default {
  name: "TextQuestion",
  props: {
    question: {
      type: Object,
      default: () => {
        return {
          id: "1",
          title: "Rolex is a company that specializes in what type of product?",
          options: {
            a: "Bags",
            b: "Watches",
            c: "Shoes",
            d: "Laptops",
            e: "Laptops 123",
          },
          answer: "a",
          explanation: "Explanation",
          type: 3,
        };
      },
    },
  },
  data() {
    return {
      selectedAnswerShort: "",
      selectedAnswerLong: ""
    };
  },
  methods: {
    selectAnswer() {
      if (this.selectedAnswerShort === '' ) {
        console.log('null')
      } else {
        if (this.question.type === 3) {
          const answer = {
            question: this.question.id,
            answer: this.selectedAnswerShort
          }
          console.log(answer)
          this.$emit('selectAnswer', answer)
        } 
        else {
          const answer = {
            question: this.question.id,
            answer: this.selectedAnswerShort
          }
          console.log(answer)
          this.$emit('selectAnswer', answer)
        }
      }
    },
  },
};
</script>

<style scoped>
.mainQuestion input, .mainQuestion textarea {
  padding: 8px;
  outline: none;
  border-radius: 5px;
  border: 1px solid grey;
  font-size: 18px;
}

.mainQuestion textarea {
  height: 120px;
}

@media only screen and (max-width: 750px) {
  .questionTitle {
    font-size: 18px;
  }

  .input_label {
    padding: 10px;
  }
}
</style>